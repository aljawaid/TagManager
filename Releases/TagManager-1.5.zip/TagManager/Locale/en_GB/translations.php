<?php

return array(
    //
    // GENERAL
    //
    'Tags management' => 'Tag Manager',
    'Global tags management' => 'Tag Manager',
    'Project tags management' => 'Project Tags',
);
